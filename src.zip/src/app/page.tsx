"use client";

import { Button } from "antd";
import { useRef } from "react";

export default function Home() {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files && event.target.files[0];
    if (file) {
      // Process the file here (e.g., send it to the backend)
    }
  };

  return (
    <div className="flex h-screen">
      {/* Left Half */}
      <div className="flex-1 bg-gray-100 flex justify-center items-center">
        <input
          placeholder="upload you file"
          type="file"
          ref={fileInputRef}
          onChange={handleFileUpload}
          className="hidden"
        />
        <Button
          type="primary"
          onClick={() => fileInputRef.current && fileInputRef.current.click()}
        >
          Upload File
        </Button>
      </div>

      {/* Right Half */}
      <div className="flex-1 bg-gray-200"> {/* Content for right half */} </div>
    </div>
  );
}
